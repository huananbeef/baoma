import Vue from 'vue'
import App from './App'
import AV from './common/av-weapp.js'
// import globalUI from './static'

const appId = "YFzggloQWOnyQPwmXGnRHnGW-gzGzoHsz";
const appKey = "5pJ2hDHl7FOTWElqoEADa6kR";

AV.init({
	appId: appId,
	appKey: appKey
});

// Vue.use(globalUI)

Vue.config.productionTip = false

// const AV = require('./common/av-weapp-min.js');
//app.js



App.mpType = 'app'

const app = new Vue({
	...App
})
app.$mount()
