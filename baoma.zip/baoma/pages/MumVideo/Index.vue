<template>
<view class="grace-padding">
       
        <!-- 选项卡 -->
        <view class="grace-tab">
            <scroll-view class="grace-tab-title" scroll-x="true">
                <view v-for="(tab, index) in tabs" wx:for-index="index" v-for-item="tab" :class="[tabCurrentIndex == index ? 'grace-tab-current' : '']" :id="'tabTag-'+index" @tap="tabChange">{{tab.name}}</view>
            </scroll-view>
            <swiper class="grace-tab-swiper" :current="swiperCurrentIndex" @change="swiperChange" style="height:350rpx;">
                <swiper-item>
                    <navigator>关注列表...</navigator>
                    <navigator>关注列表...</navigator>
                    <navigator>关注列表...</navigator>
                    <navigator>关注列表...</navigator>
                    <navigator>关注列表...</navigator>
                </swiper-item>
                <swiper-item>推荐</swiper-item>
                <swiper-item>体育</swiper-item>
                <swiper-item>热点</swiper-item>
                <swiper-item>财经</swiper-item>
                <swiper-item>娱乐</swiper-item>
            </swiper>
        </view>
        <!-- 选项卡 -->
    </view>

</template>
<script>
export default {
    data: {
        tabCurrentIndex: 0,
        swiperCurrentIndex: 0,
        tabs: [
            { name: '关注', id: 'guanzhu' },
            { name: '推荐', id: 'tuijian' },
            { name: '体育', id: 'tiyu' },
            { name: '热点', id: 'redian' },
            { name: '财经', id: 'caijing' },
            { name: '娱乐', id: 'yule' }
        ]
    },
    methods: {
        tabChange: function(e) {
            var index = e.target.id.replace('tabTag-', '');
            this.swiperCurrentIndex = index;
            this.tabCurrentIndex = index;
        },
        swiperChange: function(e) {
            var index = e.detail.current;
            this.tabCurrentIndex = index;
        }
    }
};
</script>
<style>
</style>
