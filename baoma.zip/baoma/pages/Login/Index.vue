<template>
    <view class="grace-padding">
        <view class="grace-h2 grace-blod" style="margin-top:100rpx; color:#FFFFFF;">手机登录</view>
        <view class="grace-text-small" style="margin-top:5rpx; color:#FFFFFF;">
            请输入手机号获取验证码登录
        </view>
        <view class="grace-form" style="margin-top:50rpx;">
            <form>
                <view class="grace-items grace-items-wbg">
                    <view class="grace-label">
                        <picker :value="pnpre" @change="changePre" :range="pnpres" name="pn_pre">
                            <text>+{{pnpre}}</text>
                        </picker>
                    </view>
                    <input type="number"  name="user_phone" v-model="user_phone" placeholder="请输入手机号"></input>
                </view>
                <view style="justify-content:space-between; margin-top:28rpx;">
                    <view class="grace-items grace-items-wbg" style="width:66%;">
                        <view class="grace-label" style="justify-content:center;"><text>验证码</text></view>
                        <input type="mumber" name="user_vcode"  v-model="user_vcode" placeholder="请输入验证码"></input>
                    </view>
                    <view style="width:32%;  margin-left:2%; paading:0;">
                        <button type="number"   @tap="PhoneClick" style="background:#5D6AB4; color:#FFFFFF; width:100%; height:88rpx; line-height:88rpx;">获取验证码</button>
                    </view>
                </view>
            </form>
        </view>
        <view class="grace-center" style="margin-top:80rpx; color:#FFFFFF; line-height:80rpx; font-size:36rpx;">
           <button @type="primary"   @tap="loginforuser">登录</button> <text class="grace-iconfont icon-arrow-right"></text>
        </view>
        <view class="grace-center" style="margin-top:20rpx; color:#FFFFFF; line-height:50rpx;">
            还没有账号？点击注册
        </view>
    </view>
</template>
<script>
export default {
    data: {
        pnpre: '86',
        pnpres: ['86', '01', '11', '26', '520'],
        user_vcode: '',
        user_phone: ''
    },
    methods: {
        PhoneClick: function() {
            console.log(this.user_phone);
            //判断手机号是否正确
            var reg = 11 && /^((13|14|15|17|18)[0-9]{1}\d{8})$/;
            if (this.user_phone == '') {
                console.log('请输入手机号');
                return;
            }
            if (reg.test(this.user_phone)) {
                console.log('手机号合格 可以发送到后台');

                return;
            }
            console.log('手机号格式不正确');
        },
				loginforuser: function() {
					console.log("是否要登录");
						console.log(this.user_vcode);
						//根据用户的注册码 判断是否一致 并登录系统
						if(this.user_vcode==""){
							console.log("请输入验证码");
							return;
						}
					
					uni.redirectTo({
						url:'../../pages/index/index'
					});
				}
    },
    changePre: function(e) {
        this.pnpre = this.pnpres[e.detail.value];
    },
	
    
};
</script>
<style>
page {
    width: 750upx;
    min-height: 100%;
    background: linear-gradient(45deg, #5a3694 0, #13bdce 33%, #0094d9 66%, #6fc7b5 100%);
    background-size: 400%;
    background-position: 0 100%;
    animation: gradient 20s ease-in-out infinite;
}
</style>
