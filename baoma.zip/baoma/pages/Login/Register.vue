<template>
    <view class="grace-padding">
        <view class="grace-h2 grace-blod" style="margin-top:100rpx; color:#FFFFFF;">注册页面</view>
        <view class="grace-text-small" style="margin-top:5rpx; color:#FFFFFF;">
            请输入手机号获取验证码登录
        </view>
        <view class="grace-form" style="margin-top:50rpx;">
            <form>
                <view class="grace-items grace-items-wbg">
                    <view class="grace-label">
                        <picker :value="pnpre" @change="changePre" :range="pnpres" name="pn_pre">
                            <text>+{{pnpre}}</text>
                        </picker>
                    </view>
                    <input type="number" name="name" placeholder="请输入手机号"></input>
                </view>
                <view style="justify-content:space-between; margin-top:28rpx;">
                    <view class="grace-items grace-items-wbg" style="width:66%;">
                        <view class="grace-label" style="justify-content:center;"><text>验证码</text></view>
                        <input type="number" name="name" placeholder="请输入验证码"></input>
                    </view>
                    <view style="width:32%;  margin-left:2%; paading:0;">
                        <button type="primary" style="background:#5D6AB4; color:#FFFFFF; width:100%; height:88rpx; line-height:88rpx;">获取验证码</button>
                    </view>
                </view>
            </form>
        </view>
        <view class="grace-center" style="margin-top:80rpx; color:#FFFFFF; line-height:80rpx; font-size:36rpx;">
            登录 <text class="grace-iconfont icon-arrow-right"></text>
        </view>
        <view class="grace-center" style="margin-top:20rpx; color:#FFFFFF; line-height:50rpx;">
            还没有账号？点击注册
        </view>
    </view>
</template>
<script>
export default {
    data: {
        pnpre: '86',
        pnpres: ['86', '01', '11', '26', '520']
    },
    changePre: function(e) {
        this.pnpre = this.pnpres[e.detail.value];
    }
};
</script>
<style>
page {
    width: 750upx;
    min-height: 100%;
    background: linear-gradient(45deg, #5a3694 0, #13bdce 33%, #0094d9 66%, #6fc7b5 100%);
    background-size: 400%;
    background-position: 0 100%;
    animation: gradient 20s ease-in-out infinite;
}
</style>
