<template>
	<view>
		<scroll-view class="grace-tab-title grace-center icontitle" scroll-x="true" id="grace-tab-title">
			<image src="../../static/imgs/bmore.png" class="grace-list-imgs-l" mode="widthFix" @click="openMask()"></image>
			<image src="../../static/imgs/plus.png" class="grace-list-imgs-r" mode="widthFix"></image>
			<image src="../../static/imgs/camera.png" class="grace-list-imgs-l" mode="widthFix"></image>
			
			
			
			<view v-for="(tab, index) in tabs" :class="[tabCurrentIndex == index ? 'grace-tab-current' : '']" :id="'tabTag-'+index"
			 @tap="tabChange">{{tab.name}}</view>
			
		</scroll-view>
		<swiper class="grace-tab-swiper-full" :current="swiperCurrentIndex" @change="swiperChange" :style="'height:'+tabHeight+'rpx;'">
			<!-- 项目1 -->
			<swiper-item>
				<scroll-view scroll-y="true" @scrolltolower="scrollend1">
					<view class="grace-padding">
						<!-- 文章详情 start -->
						<view class="grace-h4 grace-blod">Flex 布局教程 (文章详情及评论界面)</view>
						<view class="grace-text-small">来源 : 阮一峰博客</view>
						<view class="grace-text" style="margin-top:12rpx;">
							<image src="../../static/imgs/text-banner.png" mode="widthFix"></image>
							<text>布局的传统解决方案，基于盒状模型，依赖 display 属性 + position属性 + float属性。它对于那些特殊布局非常不方便，比如，垂直居中就不容易实现。
								2009年，W3C 提出了一种新的方案----Flex 布局，可以简便、完整、响应式地实现各种页面布局。目前，它已经得到了所有浏览器的支持，这意味着，现在就能很安全地使用这项功能。
								<text class="grace-blod">一、Flex 布局是什么？</text>
								Flex 是 Flexible Box 的缩写，意为"弹性布局"，用来为盒状模型提供最大的灵活性。
								注意，设为 Flex 布局以后，子元素的float、clear和vertical-align属性将失效。
								<text class="grace-blod">二、基本概念</text>
								采用 Flex 布局的元素，称为 Flex 容器（flex container），简称"容器"。它的所有子元素自动成为容器成员，称为 Flex 项目（flex item），简称"项目"。
								容器默认存在两根轴：水平的主轴（main axis）和垂直的交叉轴（cross axis）。主轴的开始位置（与边框的交叉点）叫做main start，结束位置叫做main end；交叉轴的开始位置叫做cross
								start，结束位置叫做cross end。
								项目默认沿主轴排列。单个项目占据的主轴空间叫做main size，占据的交叉轴空间叫做cross size。</text>
							<image src="../../static/imgs/text-banner.png" mode="widthFix"></image>
							<text>
								<text class="grace-blod">三、容器的属性</text>
								row（默认值）：主轴为水平方向，起点在左端。
								row-reverse：主轴为水平方向，起点在右端。
								column：主轴为垂直方向，起点在上沿。
								column-reverse：主轴为垂直方向，起点在下沿。
							</text>
						</view>
						<!-- 文章详情 end-->
					</view>
				</scroll-view>
			</swiper-item>
			<!-- 项目2 -->
			<swiper-item>
				<scroll-view scroll-y="true">
					<!-- 新闻列表示例 -->
					
					<view class="grace-news-list" style="width:96%; padding:0 3%;">
						<navigator v-for="(item, index) in forData">
							<!--用户信息-->
							<view class="grace-news-list-items">
								<view class="grace-news-list-user">
									<view class="grace-news-list-user-l">
										<image src="../../static/imgs/imgde.png" class="grace-news-list-img grace-list-imgs-l" mode="widthFix"/>
										<text class="grace-news-list-username">author</text>
									</view>
									<view class="grace-news-list-user-r">
										<text class="grace-news-list-share">···</text>
									</view>
								</view>
							<!--文章信息-->	
								<view class="grace-news-list-title">
									<view class="grace-news-list-userImgs">
										<image src="../../static/icon/faxian.png" class="grace-news-list-img grace-list-imgs-content" mode=""/>
									</view>
									<view class="grace-news-list-title-main">一个项目经理不搞砸几个项目，是无法成长为一名合格的项目经理的</view>
									<text class="grace-news-list-title-desc grace-text-overflow">搞砸了就是有前途</text>
									<text class="grace-news-list-title-label">家有好宝</text>
									<view class="grace-news-list-title-functions">
										<view class="grace-news-list-title-function">
											<view class="grace-news-list-title-function-link">引用<span>159</span></view>
											<view class="grace-news-list-title-function-love">喜爱<span>998</span></view>
											<view class="grace-news-list-title-function-store">收藏<span>1161</span></view>
											<view class="grace-news-list-title-function-comments">评论<span>17</span></view>
										</view>
										<view class="grace-news-list-title-functions-comments-users">
											<text class="grace-news-list-title-functions-comment-user-name">小红:</text>
											<text class="grace-news-list-title-functions-comment-user-comment">非常棒的作品</text>
											<view class="grace-news-list-title-functions-comment-user-number">共有110条评论</view>
										</view>
										<view class="grace-news-list-title-functions-comment-personal">
											<view class="grace-news-list-title-functions-comment-input">
												
												<view class="grace-news-list-mine">
													<view class="grace-news-list-title-functions-comment-personal-name">用户头像</view>
													<input type="text"  name="user_news_list_comment" v-model="user_news_list_comment" placeholder="添加评论"></input>
													<view class="grace-news-list-title-functions-comment-emoticon">表情</view>
													<view class="grace-news-list-title-functions-comment-submit">发布</view>
												</view>
											</view>
										</view>
										<text class="grace-news-list-title-data">11-14 12:38</text>
									</view>
								</view>
							</view>
						</navigator>
					</view>
					<!-- 新闻列表 -->
					
				</scroll-view>
			</swiper-item>
			<!-- 项目3 -->
			<swiper-item>
				<scroll-view scroll-y="true">
					
					
					
				</scroll-view>
			</swiper-item>
		</swiper>
		<!-- <view class="sideWrap" > -->
		<view class="mask" v-bind:style="{ display: visible }" @click="closeMask()"></view>
		<view class="sideBar" v-bind:style="{ left: left }">
			<view class="sideitem">
				<navigator url="">
					<view class="grace-list">
						<image src="../../static/imgs/home.png" class="grace-list-imgs-l" mode="widthFix"></image>
						<text class="grace-list-text">首页</text>
						<text class="grace-list-imgs-arrow grace-iconfont icon-arrow-right"></text>
					</view>
				</navigator>
			</view>
			<view class="sideitem">
				<navigator url="">
					<view class="grace-list">
						<image src="../../static/imgs/eye.png" class="grace-list-imgs-l" mode="widthFix"></image>
						<text class="grace-list-text">我的关注</text>
						<text class="grace-list-imgs-arrow grace-iconfont icon-arrow-right"></text>
					</view>
				</navigator>
			</view>
			<view class="sideitem">
				<navigator url="">
					<view class="grace-list">
						<image src="../../static/imgs/zan.png" class="grace-list-imgs-l" mode="widthFix"></image>
						<text class="grace-list-text">我的点赞</text>
						<text class="grace-list-imgs-arrow grace-iconfont icon-arrow-right"></text>
					</view>
				</navigator>
			</view>
			<view class="sideitem">
				<navigator url="">
					<view class="grace-list">
						<image src="../../static/imgs/time.png" class="grace-list-imgs-l" mode="widthFix"></image>
						<text class="grace-list-text">备忘录</text>
						<text class="grace-list-imgs-arrow grace-iconfont icon-arrow-right"></text>
					</view>
				</navigator>
			</view>
			<view class="sideitem">
				<navigator url="">
					<view class="grace-list">
						<image src="../../static/imgs/stars.png" class="grace-list-imgs-l" mode="widthFix"></image>
						<text class="grace-list-text">我的收藏</text>
						<text class="grace-list-imgs-arrow grace-iconfont icon-arrow-right"></text>
					</view>
				</navigator>
			</view>
			<view class="sideitem">
				<navigator url="">
					<view class="grace-list">
						<image src="../../static/imgs/more.png" class="grace-list-imgs-l" mode="widthFix"></image>
						<text class="grace-list-text">更多</text>
						<text class="grace-list-imgs-arrow grace-iconfont icon-arrow-right"></text>
					</view>
				</navigator>
			</view>
		</view>
		<!-- </view> -->
	</view>
</template>
<script>
	
	
	// import appHeader from '@/components/header'
	
	var _self;
	export default {
		name: 'app',
		components: {
			// appHeader
		},
		data: {
			left: '-500px',
			visible: 'none', // 侧边栏是否打开
			loading: false,
			userinfo: {
				headUrl: './static/img/head.jpg', // 头像链接
				color: ''
			},
			forData: [1, 2, 3, 4, 5, 6, 7, 8, 9, 10],
			tabCurrentIndex: 0,
			swiperCurrentIndex: 0,
			tabHeight: 300,
			tabs: [{
					name: '推荐',
					id: 'tuijian'
				},
				{
					name: '关注',
					id: 'guanzhu'
				},
				{
					name: '身边',
					id: '身边'
				}
			],
			//瀑布流部分
			loadingText: "加载中...",
			isEnd: false,
			productList : [[],[]]
		},
		onLoad: function() {
			_self = this;
		},
		onReady: function() {
			//获取屏幕高度及比例
			var winInfo = uni.getSystemInfo({
				success: function(res) {
					var pixelRatio = 750 / res.windowWidth;
					var windowHeight = res.windowHeight;
					//获取头部标题高度
					uni.createSelectorQuery().select('#grace-tab-title').fields({
						size: true,
					}, function(res) {
						console.log(pixelRatio);
						//计算得出滚动区域的高度
						var sHeight = (windowHeight - res.height) * pixelRatio;
						_self.tabHeight = sHeight;
					}).exec();
				}
			});
		},
		methods: {
			// 打开侧边栏
			openMask: function(e) {
				console.log('打开侧边栏');
				this.left = '0';
				this.visible = 'block';
			},
			closeMask: function(e) {
				console.log('关闭侧边栏');
				this.left = '-500px';
				this.visible = 'none';
				return false;
			},
			tabChange: function(e) {
				var index = e.target.id.replace('tabTag-', '');
				this.swiperCurrentIndex = index;
				this.tabCurrentIndex = index;
			},
			swiperChange: function(e) {
				var index = e.detail.current;
				this.tabCurrentIndex = index;
			},
			scrollend1: function() {
				uni.showToast({
					title: '滚动到底部，可以加载更多了 ^_^',
					icon: 'none'
				});
			}
		}
	}
</script>
<style>
	
	.grace-news-list-items{
		background:green;
		display:flex;
		flex-direction:column;
	}
	.grace-news-list-user{
		display:flex;
		flex-direction:row;
		background:red;
	}
	.grace-news-list-user view{
		flex:1;
	}
	
	.grace-news-list-user-l{
		width:100%;
		
		height:60upx;
		display:flex;
		flex-direction:row;
		align-items: center;
	}
	.grace-news-list-user-r{
		display:flex;
		flex-direction:row;
		align-items:center;
	}
	.grace-list-imgs-l {
		height: 56upx;
		width: 54upx;
		display:block;
		border-radius:50%;
	}
	
	.grace-news-list-username{
		
	}
	
	
	.grace-news-list-userImgs{
		height:300upx;
		background:#46A4DA;
		
	}
	.grace-news-list-userImgs image{
		height:100%;
		width:100%;
	}
	
	.grace-list-imgs-content{
		height:100upx;
		width:120upx;
		
	}
	
	.grace-news-list-title-function{
		background:#4CD964;
		display:flex;
		flex-direction: row;
	}
	.grace-news-list-title-function view{
		flex:1;
	}
	.grace-news-list-title-functions-comment-input{
		background:#46A4DA;
		
	}
	.grace-news-list-mine{
		display:flex;
	}
	.grace-news-list-mine view{
		flex:1;
	}
	
	


	.icontitle image {
		width: 45upx;
		height: 45upx;
		position: absolute;
		top: 20upx;
	}
	.icontitle image:first-child {
		left: 30upx;
	}
	.icontitle image:nth-child(2) {
		left: 80upx;
	}
	.icontitle image:nth-child(3) {
		right: 30upx;
	}

	.homeico text {
		font-size: 34upx;
		text-align: center;
	}

	.sideWrap {
		position: fixed;
		width: 100%;
		height: 100%;
		top: 0;
		left: 0;
		background: rgba(0, 0, 0, 0);
	}

	.mask {
		position: fixed;
		width: 100%;
		height: 100%;
		top: 0;
		left: 0;
		background: rgba(0, 0, 0, .4);
		-webkit-transition: all ease .4s;
		transition: all ease .4s;

	}

	.visible {
		left: -500px;
	}

	.sideBar {
		display: block;
		position: absolute;
		top: 0;
		left: 0;
		width: 40%;
		height: 100%;
		overflow: hidden;
		background: #333;
		min-width: 170px;
	}

	.sideitem {
		background: #333;
		width: 100%;
	}

	.sideitem navigator {
		width: 100%;
	}

	.sideitem .grace-list {
		width: 100%;
		box-sizing: border-box;
		color: #FFFFFF;
	}

	.grace-list-imgs-arrow {
		color: #FFFFFF;
		line-height: 50upx;
	}
</style>
<style lang="scss" rel="stylesheet/scss">
	html {
		font-size: 62.5%;
	}

	body {
		position: absolute;
		margin: 0;
		padding: 0;
		width: 100%;
		min-height: 100%;
	}

	#app {
		font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto,
			"Helvetica Neue", Helvetica, "PingFang SC", "Hiragino Sans GB", "Microsoft YaHei",
			SimSun, sans-serif;
		-webkit-font-smoothing: antialiased;
		-moz-osx-font-smoothing: grayscale;

		.g-loading {
			position: fixed;
			top: 50%;
			left: 50%;
			margin-left: -14px;
			margin-top: -14px;
		}
	}
</style>
