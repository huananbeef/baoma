<template>
	<view class="main">
		<view class="mywrap">
			<view class="mytitle">
				<view class="title">我</view>
				<view class="myset">
					<image src="../../static/imgs/set.png" mode=""></image>
				</view>
			</view>
		</view>
		<view class="mywrap">
			<view class="myintro">
				<view class="introtop">
					<view class="myinfo">
						<view class="myimg">
							<image src="../../static/icon/my.png" mode=""></image>
						</view>
						<view class="mytxt">
							<view class="myname">用户名</view>
							<view class="myjian">简介：暂无介绍</view>
						</view>
					</view>
					<view class="myvip">
						<view class="vipimg">
							<image src="../../static/icon/goodShop.png" mode=""></image>
						</view>
						<view class="viptxt">会员></view>
					</view>
				</view>
				<view class="introbtm">
					<view class="btmview">
						<view class="btmnum">82</view>
						<view class="btmtxt">微博</view>
					</view>
					<view class="btmview">
						<view class="btmnum">40</view>
						<view class="btmtxt">关注</view>
					</view>
					<view class="btmview">
						<view class="btmnum">34</view>
						<view class="btmtxt">粉丝</view>
					</view>
				</view>
			</view>
		</view>
		<view class="mywrap">
			<view class="grace-padding">
				<view style="padding:20rpx 0;">
					<navigator class="grace-boxes">
						<view class="grace-boxes-img">
							<image src="../../static/imgs/boxes-1.png" mode="widthFix"></image>
						</view>
						<view class="grace-boxes-text">我的相册</view>
					</navigator>
					<navigator class="grace-boxes">
						<view class="grace-boxes-img">
							<image src="../../static/imgs/boxes-2.png" mode="widthFix"></image>
						</view>
						<view class="grace-boxes-text">我的故事</view>
					</navigator>
					<navigator class="grace-boxes">
						<view class="grace-boxes-img">
							<image src="../../static/imgs/boxes-3.png" mode="widthFix"></image>
						</view>
						<view class="grace-boxes-text">我的赞</view>
					</navigator>
					<navigator class="grace-boxes">
						<view class="grace-boxes-img">
							<image src="../../static/imgs/boxes-4.png" mode="widthFix"></image>
						</view>
						<view class="grace-boxes-text">粉丝服务</view>
					</navigator>
					<navigator class="grace-boxes">
						<view class="grace-boxes-img">
							<image src="../../static/imgs/boxes-4.png" mode="widthFix"></image>
						</view>
						<view class="grace-boxes-text">钱包</view>
					</navigator>
					<navigator class="grace-boxes">
						<view class="grace-boxes-img">
							<image src="../../static/imgs/boxes-3.png" mode="widthFix"></image>
						</view>
						<view class="grace-boxes-text">运动</view>
					</navigator>
					<navigator class="grace-boxes">
						<view class="grace-boxes-img">
							<image src="../../static/imgs/boxes-2.png" mode="widthFix"></image>
						</view>
						<view class="grace-boxes-text">头条</view>
					</navigator>
					<navigator class="grace-boxes">
						<view class="grace-boxes-img">
							<image src="../../static/imgs/boxes-1.png" mode="widthFix"></image>
						</view>
						<view class="grace-boxes-text">客服中心</view>
					</navigator>
				</view>
			</view>
		</view>
		<view class="mywrap">
			<view class="mytopic">
				<view class="toptxt">社区</view>
				<view class="topictitle">来自你关注的社区热门</view>
				<view class="grace-news-list-items">
					<image src="../../static/imgs/imgde.png" class="grace-news-list-img grace-list-imgs-l" mode="widthFix"></image>
					<view class="grace-news-list-title">
						<view class="grace-news-list-title-main">话题标题</view>
						<text class="grace-news-list-title-desc grace-text-overflow">话题详情话题详情话题详情话题详情话题详情话题详情话题详情话题详情</text>
					</view>
				</view>
			</view>
			<view class="topicAll">查看全部</view>
		</view>
	</view>
</template>

<script>
	export default {
		data() {
			return {

			};
		}
	}
</script>

<style>
	page {
		background: #f0f0f0;
	}

	.mywrap {
		background: #FFFFFF;
		margin-bottom: 20upx;
		border-top: 1px solid #e6e6e6;
		border-bottom: 1px solid #e6e6e6;
	}

	.myintro {}

	.mytitle {
		height: 90upx;
		display: flex;
		position: relative;
	}

	.title {
		flex: 1;
		font-size: 32upx;
		line-height: 90upx;
		text-align: center;
		justify-content: center;
	}

	.myset {
		position: absolute;
		right: 40upx;
		top: 25upx;
		width: 50upx;

	}

	.myset image {
		width: 40upx;
		height: 40upx;
	}

	.introtop {
		position: relative;
		padding: 20upx 30upx;
		border-bottom: 1px solid #E6E6E6;
	}

	.myinfo {
		flex: 1;
	}

	.myimg {
		width: 140upx;
		height: 140upx;
		border-radius: 50%;
		overflow: hidden;
		margin-right: 30upx;
	}

	.myimg image {
		width: 100%;
		height: 100%;
		border-radius: 50%;
	}

	.myvip {
		position: absolute;
		right: 30upx;
		top: 50%;
		transform: translate(0, -50%);
		height: 70upx;
		width: 150upx;
		float: right;

	}

	.mytxt {
		padding: 10upx 0;
		flex: 1;
		height: 70upx;
		line-height: 70upx;
	}

	.myname {
		height: 60upx;
		line-height: 60upx;
		font-size: 38upx;
		color: #333333;
	}

	.myjian {
		color: #999999;
		font-size: 26upx;
	}

	.vipimg {
		width: 50upx;
		height: 50upx;
		margin-right: 10upx;
	}

	.vipimg image {
		width: 100%;
		height: 100%;
	}

	.viptxt {
		flex: 1;
	}

	.introbtm {
		padding: 20upx 0;
	}

	.btmview {
		flex: 1;
		justify-content: center;
		text-align: center;
	}

	.btmnum {
		color: #333333;
		font-size: 32upx;
		text-align: center;
		justify-content: center;
	}

	.btmtxt {
		color: #999;
		font-size: 30upx;
		text-align: center;
		justify-content: center;
	}

	.grace-boxes {
		width: 21%;
		margin: 0 2%;
	}
	.mytopic{
		padding: 20upx 20upx 30upx;
		box-sizing: border-box;
	}
	.topictitle{
		height: 70upx;
		line-height: 70upx;
	}
	.toptxt{
		color: #999999;
		font-size: 28upx;
		margin-bottom: 10upx;
	}
	.topicAll{
		height: 90upx;
		line-height: 90upx;
		font-size: 32upx;
		background: #F8F8F8;
		color: #6270a1;
		text-align: center;
		justify-content: center;
	}
</style>
